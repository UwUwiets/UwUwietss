# Architecture
Layers: `core` (pure Kotlin config/binds/stats, JVM-testable) → `AppViewModel` (state, async save) → `ui` (Compose) → `MainActivity` (key dispatch, lifecycle).

## Integration with Minecraft Bedrock 1.26.32.2 (no root) — honest status
| Path | Can do | Cannot do | Status |
|---|---|---|---|
| Standalone Android app (built) | Own UI, configs, monitors of device RAM/thermal, detect installed Minecraft version | Read Minecraft's FPS, change its rendering, capture its input | Implemented, unverified |
| Resource/behavior packs, Script API (`.mcpack`) | Some UI/particle/pack-level tweaks, in-world scripted utilities | Global client settings, FPS measurement, anything outside pack sandbox | Requires compatibility research |
| Native hook / `.so` injection | Everything in theory | Without root needs repackaged, re-signed APK (breaks Play licensing/Xbox login risk), offsets are per-version, I have no verified offsets or compatible source | Requires compatibility research — no code written |
| Overlay window (SYSTEM_ALERT_WINDOW) | Draw widgets over the game, show device stats | Measure game frames (needs adb/root) | Not started |

Research steps: `unzip -l minecraft.apk` (check `lib/arm64-v8a/libminecraftpe.so`), confirm what Script API modules 26.x exposes on mobile, evaluate a legal, open-source compatible loader before any native work.

## Config
JSON at `filesDir/config/config.json`, typed `AppConfig`, `schemaVersion` + `ConfigMigrator` step chain, atomic save, corrupt file moved aside.
## Binds
`BindEngine` per device; winner = priority then combo size; PRESS/HOLD/TOGGLE; `releaseAll()` on focus loss; conflicts = same device + identical key set. Works only on this app's own window.
## UI
Translucent panels (no real backdrop blur — not claimed). Crossfade tabs, 0 ms with reduced motion.
