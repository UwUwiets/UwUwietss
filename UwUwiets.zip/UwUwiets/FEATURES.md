# FEATURES (165)

No result here is measured. 'Implemented, unverified' = code + unit tests written, nothing compiled or run yet. Game-dependent items stay 'research' until a mechanism is proven on 1.26.32.2.

| # | Feature | Category | Prio | Mechanism | Status |
|---|---|---|---|---|---|
| 1 | Client FPS counter | A. Performance & FPS | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 2 | Client frame-time avg / 1% low | A. Performance & FPS | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 3 | Memory monitor | A. Performance & FPS | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 4 | Thermal & battery temp monitor | A. Performance & FPS | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 5 | Profiles Low/Balanced/Quality/Custom (stored only) | A. Performance & FPS | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 6 | In-game FPS counter | A. Performance & FPS | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 7 | In-game frame-time graph | A. Performance & FPS | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 8 | Before/after benchmark compare | A. Performance & FPS | P2 | Standalone Android code | Not started (own Android app) |
| 9 | Low-resource client mode | A. Performance & FPS | P2 | Standalone Android code | Not started (own Android app) |
| 10 | Client leak detector | A. Performance & FPS | P2 | Standalone Android code | Not started (own Android app) |
| 11 | Frame pacing report | A. Performance & FPS | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 12 | Session min/max FPS log | A. Performance & FPS | P2 | Standalone Android code | Not started (own Android app) |
| 13 | Render distance control | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 14 | Particle limiter | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 15 | Animation toggle | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 16 | Fancy leaves toggle | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 17 | Smooth lighting toggle | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 18 | Fog distance | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 19 | Shadow quality | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 20 | Vibrant Visuals toggle | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 21 | FOV slider | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 22 | Cloud toggle | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 23 | Biome blend radius | B. Render & Visuals | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 24 | Overlay window (SYSTEM_ALERT_WINDOW) | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 25 | Draggable widgets | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 26 | Widget scaling | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 27 | HUD editor | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 28 | Clock widget | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 29 | Battery widget | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 30 | Temperature widget | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 31 | RAM widget | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 32 | Per-widget opacity | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 33 | Snap-to-grid layout | C. HUD & Overlay | P2 | Standalone Android code | Not started (own Android app) |
| 34 | Coordinates widget | C. HUD & Overlay | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 35 | Dark glass theme | D. Interface & Themes | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 36 | Glass opacity slider | D. Interface & Themes | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 37 | Reduced motion | D. Interface & Themes | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 38 | Module search | D. Interface & Themes | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 39 | Favorites | D. Interface & Themes | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 40 | Tab transitions | D. Interface & Themes | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 41 | Module detail page | D. Interface & Themes | P2 | Standalone Android code | Not started (own Android app) |
| 42 | Animation intensity | D. Interface & Themes | P2 | Standalone Android code | Not started (own Android app) |
| 43 | Accent colors | D. Interface & Themes | P2 | Standalone Android code | Not started (own Android app) |
| 44 | Density mode | D. Interface & Themes | P2 | Standalone Android code | Not started (own Android app) |
| 45 | UI scale | D. Interface & Themes | P2 | Standalone Android code | Not started (own Android app) |
| 46 | True backdrop blur (limited) | D. Interface & Themes | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 47 | Single-key bind | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 48 | Key combos | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 49 | Press mode | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 50 | Hold mode | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 51 | Toggle mode | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 52 | Combo priority | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 53 | Conflict detection | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 54 | Clear / reset bind | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 55 | Focus-loss release | E. Input & Keybinds | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 56 | Bind profiles | E. Input & Keybinds | P2 | Standalone Android code | Not started (own Android app) |
| 57 | Bind export/import | E. Input & Keybinds | P2 | Standalone Android code | Not started (own Android app) |
| 58 | Hardware key capture UI | E. Input & Keybinds | P2 | Standalone Android code | Not started (own Android app) |
| 59 | Gamepad binds | E. Input & Keybinds | P2 | Standalone Android code | Not started (own Android app) |
| 60 | Auto-repeat mode | E. Input & Keybinds | P2 | Standalone Android code | Not started (own Android app) |
| 61 | Inject keys into game | E. Input & Keybinds | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 62 | Typed config schema | F. Profiles & Config | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 63 | Config migrations | F. Profiles & Config | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 64 | Atomic save | F. Profiles & Config | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 65 | Corrupt-config recovery | F. Profiles & Config | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 66 | Profile export | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 67 | Profile import | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 68 | Settings backup | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 69 | Settings restore | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 70 | Per-module settings | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 71 | Reset to defaults | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 72 | Enable/disable all | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 73 | Profile switch bind | F. Profiles & Config | P2 | Standalone Android code | Not started (own Android app) |
| 74 | Overlay touch layout presets | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 75 | Button resize | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 76 | Button opacity | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 77 | Layout drag editor | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 78 | Swipe gestures | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 79 | Haptic feedback | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 80 | Lock layout | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 81 | Sensitivity profile | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 82 | Edge-safe zones | G. Touch Controls | P2 | Standalone Android code | Not started (own Android app) |
| 83 | Modify game's own touch layout | G. Touch Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 84 | Reduced motion | H. Accessibility | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 85 | Large text | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 86 | High contrast | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 87 | TalkBack labels | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 88 | Color-blind palettes | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 89 | Min touch targets | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 90 | Haptic options | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 91 | Simplified mode | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 92 | Focus order | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 93 | Text scale | H. Accessibility | P2 | Standalone Android code | Not started (own Android app) |
| 94 | Master volume | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 95 | Per-category volume | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 96 | Mute when backgrounded | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 97 | Audio profiles | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 98 | Music pause | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 99 | Sound ducking | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 100 | Mono audio | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 101 | Audio log | I. Audio Controls | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 102 | Debug log | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 103 | Log viewer | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 104 | Crash log capture | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 105 | Diagnostics dashboard | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 106 | Export logs | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 107 | Log level | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 108 | Perf session recorder | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 109 | Battery stats | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 110 | Storage stats | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 111 | Thermal history | J. Diagnostics & Logging | P2 | Standalone Android code | Not started (own Android app) |
| 112 | Minecraft install/version detect | J. Diagnostics & Logging | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 113 | Pack scanner (SAF) | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 114 | Pack size report | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 115 | Duplicate pack detect | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 116 | World size report | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 117 | Cache cleaner (own) | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 118 | World backup (SAF) | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 119 | Pack manifest validator | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 120 | Pack dependency check | K. Resource Management | P2 | Standalone Android code | Not started (own Android app) |
| 121 | Pack order editor | K. Resource Management | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 122 | Stopwatch | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 123 | Notepad | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 124 | Seed notes | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 125 | Waypoint list (manual) | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 126 | Screenshot organizer | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 127 | Day-cycle timer | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 128 | Command snippets library | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 129 | Stack/chunk calculator | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 130 | Biome notes | L. World & Gameplay Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 131 | Auto-read coordinates | L. World & Gameplay Utilities | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 132 | Server notes list | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 133 | Server ping tool (RakNet unconnected ping) | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 134 | Server MOTD query | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 135 | Favorite servers | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 136 | Server profiles | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 137 | Network type monitor | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 138 | Connection log | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 139 | Join-link opener | M. Multiplayer & Server Utilities | P2 | Standalone Android code | Not started (own Android app) |
| 140 | Generate performance resource pack | N. Resource Pack Integration | P2 | Standalone Android code | Not started (own Android app) |
| 141 | Pack manifest generator | N. Resource Pack Integration | P2 | Standalone Android code | Not started (own Android app) |
| 142 | .mcpack importer | N. Resource Pack Integration | P2 | Standalone Android code | Not started (own Android app) |
| 143 | Pack installer via intent | N. Resource Pack Integration | P2 | Standalone Android code | Not started (own Android app) |
| 144 | Pack template library | N. Resource Pack Integration | P2 | Standalone Android code | Not started (own Android app) |
| 145 | UI JSON tweaks | N. Resource Pack Integration | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 146 | Particle-reduction pack | N. Resource Pack Integration | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 147 | Render controller tweaks | N. Resource Pack Integration | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 148 | Pack toggler | N. Resource Pack Integration | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 149 | Config inspector | O. Developer Tools | P2 | Standalone Android code | Not started (own Android app) |
| 150 | Feature-flag screen | O. Developer Tools | P2 | Standalone Android code | Not started (own Android app) |
| 151 | Module status viewer | O. Developer Tools | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 152 | Event log | O. Developer Tools | P2 | Standalone Android code | Not started (own Android app) |
| 153 | Script API pack generator | O. Developer Tools | P2 | Standalone Android code | Not started (own Android app) |
| 154 | Mock data mode | O. Developer Tools | P2 | Standalone Android code | Not started (own Android app) |
| 155 | Test harness | O. Developer Tools | P2 | Standalone Android code | Not started (own Android app) |
| 156 | Native bridge probe | O. Developer Tools | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 157 | Bedrock .so inspector | O. Developer Tools | P3 | Needs Script API / pack / native hook - unproven | Requires compatibility research |
| 158 | Safe mode | P. Security & Stability | P2 | Standalone Android code | Not started (own Android app) |
| 159 | Crash-loop guard | P. Security & Stability | P2 | Standalone Android code | Not started (own Android app) |
| 160 | Permission audit | P. Security & Stability | P2 | Standalone Android code | Not started (own Android app) |
| 161 | No password-field capture (no accessibility service) | P. Security & Stability | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 162 | Config integrity check | P. Security & Stability | P2 | Standalone Android code | Not started (own Android app) |
| 163 | Background task limiter | P. Security & Stability | P2 | Standalone Android code | Not started (own Android app) |
| 164 | Lifecycle-safe monitors | P. Security & Stability | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
| 165 | No secrets in APK | P. Security & Stability | P1 | Own app code (see README) | Implemented, unverified (not yet built/run) |
