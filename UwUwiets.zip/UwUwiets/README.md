# UwUwiets Client (0.1.0)
Open this folder in Android Studio (Ladybug+, JDK 17), let it sync, Run on Redmi 13C. CLI: `gradle wrapper && ./gradlew testDebugUnitTest assembleDebug`.
Deps: AndroidX core/activity/lifecycle (Apache-2.0), Compose + Material3 (Apache-2.0), kotlinx-serialization (Apache-2.0), JUnit (EPL-1.0, test).
Regenerate catalog: `python3 tools/gen_features.py`.
Status: nothing compiled or run yet; see FEATURES.md and ARCHITECTURE.md. The app does NOT change Minecraft.
