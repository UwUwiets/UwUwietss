# Generates FEATURES.md. flags: i = implemented (unverified, not yet built), s = standalone not started, g = needs game integration
C = [
("A. Performance & FPS","g",["Client FPS counter|i","Client frame-time avg / 1% low|i","Memory monitor|i","Thermal & battery temp monitor|i","Profiles Low/Balanced/Quality/Custom (stored only)|i","In-game FPS counter","In-game frame-time graph","Before/after benchmark compare|s","Low-resource client mode|s","Client leak detector|s","Frame pacing report","Session min/max FPS log|s"]),
("B. Render & Visuals","g",["Render distance control","Particle limiter","Animation toggle","Fancy leaves toggle","Smooth lighting toggle","Fog distance","Shadow quality","Vibrant Visuals toggle","FOV slider","Cloud toggle","Biome blend radius"]),
("C. HUD & Overlay","s",["Overlay window (SYSTEM_ALERT_WINDOW)","Draggable widgets","Widget scaling","HUD editor","Clock widget","Battery widget","Temperature widget","RAM widget","Per-widget opacity","Snap-to-grid layout","Coordinates widget|g"]),
("D. Interface & Themes","s",["Dark glass theme|i","Glass opacity slider|i","Reduced motion|i","Module search|i","Favorites|i","Tab transitions|i","Module detail page","Animation intensity","Accent colors","Density mode","UI scale","True backdrop blur (limited)|g"]),
("E. Input & Keybinds","s",["Single-key bind|i","Key combos|i","Press mode|i","Hold mode|i","Toggle mode|i","Combo priority|i","Conflict detection|i","Clear / reset bind|i","Focus-loss release|i","Bind profiles","Bind export/import","Hardware key capture UI","Gamepad binds","Auto-repeat mode","Inject keys into game|g"]),
("F. Profiles & Config","s",["Typed config schema|i","Config migrations|i","Atomic save|i","Corrupt-config recovery|i","Profile export","Profile import","Settings backup","Settings restore","Per-module settings","Reset to defaults","Enable/disable all","Profile switch bind"]),
("G. Touch Controls","s",["Overlay touch layout presets","Button resize","Button opacity","Layout drag editor","Swipe gestures","Haptic feedback","Lock layout","Sensitivity profile","Edge-safe zones","Modify game's own touch layout|g"]),
("H. Accessibility","s",["Reduced motion|i","Large text","High contrast","TalkBack labels","Color-blind palettes","Min touch targets","Haptic options","Simplified mode","Focus order","Text scale"]),
("I. Audio Controls","g",["Master volume","Per-category volume","Mute when backgrounded","Audio profiles","Music pause","Sound ducking","Mono audio","Audio log"]),
("J. Diagnostics & Logging","s",["Debug log","Log viewer","Crash log capture","Diagnostics dashboard","Export logs","Log level","Perf session recorder","Battery stats","Storage stats","Thermal history","Minecraft install/version detect|i"]),
("K. Resource Management","s",["Pack scanner (SAF)","Pack size report","Duplicate pack detect","World size report","Cache cleaner (own)","World backup (SAF)","Pack manifest validator","Pack dependency check","Pack order editor|g"]),
("L. World & Gameplay Utilities","s",["Stopwatch","Notepad","Seed notes","Waypoint list (manual)","Screenshot organizer","Day-cycle timer","Command snippets library","Stack/chunk calculator","Biome notes","Auto-read coordinates|g"]),
("M. Multiplayer & Server Utilities","s",["Server notes list","Server ping tool (RakNet unconnected ping)","Server MOTD query","Favorite servers","Server profiles","Network type monitor","Connection log","Join-link opener"]),
("N. Resource Pack Integration","g",["Generate performance resource pack|s","Pack manifest generator|s",".mcpack importer|s","Pack installer via intent|s","Pack template library|s","UI JSON tweaks","Particle-reduction pack","Render controller tweaks","Pack toggler"]),
("O. Developer Tools","s",["Config inspector","Feature-flag screen","Module status viewer|i","Event log","Script API pack generator","Mock data mode","Test harness","Native bridge probe|g","Bedrock .so inspector|g"]),
("P. Security & Stability","s",["Safe mode","Crash-loop guard","Permission audit","No password-field capture (no accessibility service)|i","Config integrity check","Background task limiter","Lifecycle-safe monitors|i","No secrets in APK|i"]),
]
S = {"i":"Implemented, unverified (not yet built/run)","s":"Not started (own Android app)","g":"Requires compatibility research"}
rows, n = [], 0
for cat, d, items in C:
    for it in items:
        name, _, f = it.partition("|"); f = f or d; n += 1
        mech = {"i":"Own app code (see README)","s":"Standalone Android code","g":"Needs Script API / pack / native hook - unproven"}[f]
        rows.append(f"| {n} | {name} | {cat} | {'P1' if f=='i' else 'P2' if f=='s' else 'P3'} | {mech} | {S[f]} |")
assert n >= 160, n
open("../FEATURES.md","w").write("# FEATURES (%d)\n\nNo result here is measured. 'Implemented, unverified' = code + unit tests written, nothing compiled or run yet. Game-dependent items stay 'research' until a mechanism is proven on 1.26.32.2.\n\n| # | Feature | Category | Prio | Mechanism | Status |\n|---|---|---|---|---|---|\n" % n + "\n".join(rows) + "\n")
print(n)
