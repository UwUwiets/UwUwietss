package com.uwuwiets.client.core

/**
 * Key-combo engine for ONE device type. Only handles events delivered to this app's own window;
 * it does NOT control the Minecraft engine. emit(action, active) is called on state changes.
 * Winner among satisfied bindings = highest priority, then largest combo.
 */
class BindEngine(var bindings: List<Binding>, private val device: Device = Device.KEYBOARD,
                 private val emit: (String, Boolean) -> Unit) {
    private val pressed = mutableSetOf<Int>()
    private val toggled = mutableSetOf<String>()
    private var active: Binding? = null

    fun keyDown(code: Int) { if (pressed.add(code)) update() }
    fun keyUp(code: Int) { if (pressed.remove(code)) update() }
    /** Call on window focus loss so nothing stays logically held. */
    fun releaseAll() { pressed.clear(); update() }

    private fun update() {
        val win = bindings.filter { it.device == device && it.keys.isNotEmpty() && pressed.containsAll(it.keys) }
            .maxWithOrNull(compareBy({ it.priority }, { it.keys.size }))
        if (win?.id == active?.id) return
        active?.takeIf { it.mode == BindMode.HOLD }?.let { emit(it.action, false) }
        active = win
        when (win?.mode) {
            BindMode.PRESS, BindMode.HOLD -> emit(win.action, true)
            BindMode.TOGGLE -> emit(win.action, if (toggled.remove(win.action)) false else { toggled.add(win.action); true })
            null -> {}
        }
    }

    companion object {
        /** IDs of bindings that share device + identical key set with another binding. */
        fun conflicts(list: List<Binding>): Set<String> =
            list.groupBy { it.device to it.keys }.values.filter { it.size > 1 }.flatten().map { it.id }.toSet()
    }
}
