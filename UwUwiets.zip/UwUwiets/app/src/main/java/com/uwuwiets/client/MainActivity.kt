package com.uwuwiets.client

import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.uwuwiets.client.core.BindEngine
import com.uwuwiets.client.ui.App

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()
    private lateinit var engine: BindEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        engine = BindEngine(vm.config.value.bindings) { a, on -> vm.onBind(a, on) }
        setContent { App(vm) }
    }

    // Only keys delivered to this app's own window; no accessibility service, so no password capture.
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        engine.bindings = vm.config.value.bindings
        if (e.repeatCount == 0) when (e.action) {
            KeyEvent.ACTION_DOWN -> engine.keyDown(e.keyCode)
            KeyEvent.ACTION_UP -> engine.keyUp(e.keyCode)
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus) engine.releaseAll()
    }
}
