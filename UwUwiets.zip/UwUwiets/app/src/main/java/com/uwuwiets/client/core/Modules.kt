package com.uwuwiets.client.core

enum class Status(val label: String) {
    IMPL_UNVERIFIED("Implemented, unverified"), IMPL_TESTED("Implemented and tested"),
    PROTOTYPE("UI prototype"), UNSUPPORTED("Unsupported"), RESEARCH("Requires compatibility research")
}

/** Only modules with a real effect are listed here. Everything else lives in FEATURES.md. */
data class ModuleDef(val id: String, val name: String, val category: String, val desc: String, val status: Status)

object Modules {
    const val REDUCED_MOTION = "ui.reducedMotion"
    val all = listOf(
        ModuleDef("perf.fps", "Client FPS / frame time", "Performance", "Frame stats of THIS app's UI (not Minecraft).", Status.IMPL_UNVERIFIED),
        ModuleDef("perf.sys", "Memory & thermal monitor", "Performance", "RAM, thermal status, battery temperature from Android APIs.", Status.IMPL_UNVERIFIED),
        ModuleDef(REDUCED_MOTION, "Reduced motion", "Accessibility", "Disables tab transition animations.", Status.IMPL_UNVERIFIED),
    )
}
