package com.uwuwiets.client.core

data class PerfStats(val fps: Double = 0.0, val avgMs: Double = 0.0, val low1Fps: Double = 0.0, val frames: Int = 0)

object FrameStats {
    /** frameMs: durations of recent frames. 1% low = FPS of the mean of the worst 1% frames. */
    fun compute(frameMs: Collection<Double>): PerfStats {
        if (frameMs.isEmpty()) return PerfStats()
        val avg = frameMs.average()
        val worst = frameMs.sortedDescending().take(maxOf(1, frameMs.size / 100)).average()
        return PerfStats(1000.0 / avg, avg, 1000.0 / worst, frameMs.size)
    }
}
