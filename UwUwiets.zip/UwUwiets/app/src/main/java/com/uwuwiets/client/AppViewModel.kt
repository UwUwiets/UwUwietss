package com.uwuwiets.client

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.uwuwiets.client.core.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.io.File

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val store = ConfigStore(File(app.filesDir, "config"))
    val config = MutableStateFlow(AppConfig())
    val lastBind = MutableStateFlow("—")

    init { viewModelScope.launch(Dispatchers.IO) { config.value = store.load() } }

    fun update(f: (AppConfig) -> AppConfig) {
        val n = f(config.value); config.value = n
        viewModelScope.launch(Dispatchers.IO) { store.save(n) }
    }

    fun toggleModule(id: String) = update { c ->
        if (id == Modules.REDUCED_MOTION) c.copy(ui = c.ui.copy(reducedMotion = !c.ui.reducedMotion))
        else c.copy(enabled = if (id in c.enabled) c.enabled - id else c.enabled + id)
    }

    fun isOn(c: AppConfig, id: String) = if (id == Modules.REDUCED_MOTION) c.ui.reducedMotion else id in c.enabled

    fun onBind(action: String, active: Boolean) {
        lastBind.value = "$action=${if (active) "on" else "off"}"
        if (active && Modules.all.any { it.id == action }) toggleModule(action)
    }
}
