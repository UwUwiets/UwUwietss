package com.uwuwiets.client.core

import kotlinx.serialization.json.*
import java.io.File
import java.nio.file.Files
import java.nio.file.StandardCopyOption

class ConfigStore(private val dir: File) {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; prettyPrint = true }
    private val file get() = File(dir, "config.json")

    @Synchronized
    fun load(): AppConfig {
        if (!file.exists()) return AppConfig()
        return try {
            val migrated = ConfigMigrator.migrate(json.parseToJsonElement(file.readText()).jsonObject)
            json.decodeFromJsonElement(AppConfig.serializer(), migrated)
        } catch (e: Exception) {
            // keep the user's data: move the broken file aside instead of deleting it
            file.renameTo(File(dir, "config.json.corrupt-${System.currentTimeMillis()}"))
            AppConfig()
        }
    }

    @Synchronized
    fun save(cfg: AppConfig) {
        dir.mkdirs()
        val tmp = File(dir, "config.json.tmp")
        tmp.writeText(json.encodeToString(AppConfig.serializer(), cfg))
        Files.move(tmp.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
    }
}
