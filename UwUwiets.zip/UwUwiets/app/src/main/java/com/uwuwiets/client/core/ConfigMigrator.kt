package com.uwuwiets.client.core

import kotlinx.serialization.json.*

/** Upgrades raw JSON from any older schema to CURRENT. v1 had a top-level "glassOpacity". */
object ConfigMigrator {
    const val CURRENT = 2
    private val steps: Map<Int, (JsonObject) -> JsonObject> = mapOf(
        1 to { o ->
            val ui = JsonObject(mapOf("opacity" to (o["glassOpacity"] ?: JsonPrimitive(0.6))))
            JsonObject(o - "glassOpacity" + ("ui" to ui))
        },
    )

    fun migrate(input: JsonObject): JsonObject {
        var cur = input
        var v = (cur["schemaVersion"] as? JsonPrimitive)?.intOrNull ?: 1
        while (v < CURRENT) { cur = steps.getValue(v)(cur); v++ }
        return JsonObject(cur + ("schemaVersion" to JsonPrimitive(maxOf(v, CURRENT))))
    }
}
