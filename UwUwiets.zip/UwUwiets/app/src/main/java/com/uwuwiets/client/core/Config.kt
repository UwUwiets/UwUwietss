package com.uwuwiets.client.core

import kotlinx.serialization.Serializable

enum class BindMode { PRESS, HOLD, TOGGLE }
enum class Device { KEYBOARD, GAMEPAD, TOUCH }

@Serializable
data class Binding(
    val id: String, val action: String, val keys: Set<Int>,
    val mode: BindMode = BindMode.PRESS, val priority: Int = 0, val device: Device = Device.KEYBOARD,
)

@Serializable
data class UiConfig(val opacity: Float = 0.6f, val reducedMotion: Boolean = false, val scale: Float = 1f)

@Serializable
data class AppConfig(
    val schemaVersion: Int = ConfigMigrator.CURRENT,
    val ui: UiConfig = UiConfig(),
    val enabled: Set<String> = emptySet(),
    val favorites: Set<String> = emptySet(),
    val profile: String = "Balanced",
    // Android KeyEvent codes: CTRL_LEFT=113, SHIFT_LEFT=59, F=34
    val bindings: List<Binding> = listOf(Binding("b1", "perf.fps", setOf(113, 59, 34))),
)
