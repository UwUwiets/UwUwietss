package com.uwuwiets.client.ui

import android.view.KeyEvent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.uwuwiets.client.AppViewModel
import com.uwuwiets.client.core.*
import kotlinx.coroutines.delay

private val Bg = Brush.verticalGradient(listOf(Color(0xFF0A0A0C), Color(0xFF18191D)))
private val Dim = Color(0xFFA0A3AB)

/** Translucent panel. NOTE: no real backdrop blur is implemented (Compose cannot blur what is behind). */
@Composable
fun Glass(opacity: Float, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(modifier.clip(shape).background(Color.White.copy(alpha = 0.03f + 0.12f * opacity))
        .border(1.dp, Color.White.copy(alpha = 0.14f), shape).padding(14.dp), content = content)
}

@Composable
fun App(vm: AppViewModel) {
    val cfg by vm.config.collectAsState()
    val fpsOn = "perf.fps" in cfg.enabled
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner, fpsOn) {
        val obs = LifecycleEventObserver { _, ev ->
            if (ev == Lifecycle.Event.ON_RESUME && fpsOn) PerfMonitor.start()
            if (ev == Lifecycle.Event.ON_PAUSE) PerfMonitor.stop()
        }
        owner.lifecycle.addObserver(obs)
        if (fpsOn && owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) PerfMonitor.start() else PerfMonitor.stop()
        onDispose { owner.lifecycle.removeObserver(obs); PerfMonitor.stop() }
    }
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme(colorScheme = darkColorScheme()) {
        Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding().navigationBarsPadding().padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("UwUwiets Client", style = MaterialTheme.typography.headlineSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Modules", "Binds", "Perf").forEachIndexed { i, t ->
                    FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(t) })
                }
            }
            Crossfade(tab, animationSpec = tween(if (cfg.ui.reducedMotion) 0 else 220), label = "tab") {
                when (it) { 0 -> Modules(vm, cfg); 1 -> Binds(vm, cfg); else -> Perf(vm, cfg) }
            }
        }
    }
}

@Composable
private fun Modules(vm: AppViewModel, cfg: AppConfig) {
    var q by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search modules") })
        val list = Modules.all.filter { it.name.contains(q, true) || it.category.contains(q, true) }
            .sortedByDescending { it.id in cfg.favorites }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { m ->
                Glass(cfg.ui.opacity, Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        TextButton({ vm.update { c -> c.copy(favorites = if (m.id in c.favorites) c.favorites - m.id else c.favorites + m.id) } }) {
                            Text(if (m.id in cfg.favorites) "★" else "☆")
                        }
                        Column(Modifier.weight(1f)) {
                            Text(m.name); Text("${m.category} · ${m.status.label}", color = Dim, style = MaterialTheme.typography.labelSmall)
                            Text(m.desc, color = Dim, style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(vm.isOn(cfg, m.id), { vm.toggleModule(m.id) })
                    }
                }
            }
        }
    }
}

@Composable
private fun Binds(vm: AppViewModel, cfg: AppConfig) {
    val last by vm.lastBind.collectAsState()
    val conflicts = BindEngine.conflicts(cfg.bindings)
    fun name(k: Int) = KeyEvent.keyCodeToString(k).removePrefix("KEYCODE_")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Hardware-keyboard binds act inside this app only. Last event: $last", color = Dim, style = MaterialTheme.typography.bodySmall)
        cfg.bindings.forEach { b ->
            Glass(cfg.ui.opacity, Modifier.fillMaxWidth()) {
                Text(b.keys.joinToString("+", transform = ::name) + "  →  " + b.action)
                Text("${b.mode} · ${b.device} · prio ${b.priority}" + if (b.id in conflicts) " · CONFLICT" else "", color = if (b.id in conflicts) Color(0xFFFF6B6B) else Dim)
                TextButton({ vm.update { c -> c.copy(bindings = c.bindings - b) } }) { Text("Remove") }
            }
        }
        OutlinedButton({ vm.update { it.copy(bindings = AppConfig().bindings) } }) { Text("Reset binds") }
    }
}

@Composable
private fun Perf(vm: AppViewModel, cfg: AppConfig) {
    val ctx = LocalContext.current
    val stats by PerfMonitor.stats.collectAsState()
    var snap by remember { mutableStateOf(SystemInfo.read(ctx)) }
    LaunchedEffect(Unit) { while (true) { snap = SystemInfo.read(ctx); delay(2000) } }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Glass(cfg.ui.opacity, Modifier.fillMaxWidth()) {
            Text("Minecraft: " + (snap.mcVersion ?: "not found"))
            Text(if ("perf.fps" in cfg.enabled) "Client UI: %.0f FPS · %.1f ms · 1%% low %.0f".format(stats.fps, stats.avgMs, stats.low1Fps)
                 else "Client FPS module is off", color = Dim)
            Text("RAM free ${snap.availMb}/${snap.totalMb} MB" + if (snap.lowMem) " (LOW)" else "")
            Text("Thermal status: ${snap.thermal ?: "n/a"} · battery ${snap.batteryC?.let { "%.1f°C".format(it) } ?: "n/a"}")
        }
        Glass(cfg.ui.opacity, Modifier.fillMaxWidth()) {
            Text("Glass opacity")
            Slider(cfg.ui.opacity, { v -> vm.update { it.copy(ui = it.ui.copy(opacity = v)) } })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Low", "Balanced", "Quality", "Custom").forEach { p ->
                    FilterChip(cfg.profile == p, { vm.update { it.copy(profile = p) } }, { Text(p) })
                }
            }
            Text("Profile is stored only; it does not change Minecraft yet.", color = Dim, style = MaterialTheme.typography.bodySmall)
        }
    }
}
