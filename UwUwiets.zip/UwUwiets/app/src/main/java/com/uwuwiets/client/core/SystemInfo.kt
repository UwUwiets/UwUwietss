package com.uwuwiets.client.core

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.view.Choreographer
import kotlinx.coroutines.flow.MutableStateFlow

data class SysSnapshot(val availMb: Long, val totalMb: Long, val lowMem: Boolean,
                       val thermal: Int?, val batteryC: Float?, val mcVersion: String?)

object SystemInfo {
    fun read(ctx: Context): SysSnapshot {
        val mi = ActivityManager.MemoryInfo()
        (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val thermal = if (Build.VERSION.SDK_INT >= 29)
            (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus else null
        val t = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)?.takeIf { it >= 0 }?.div(10f)
        val mc = try { ctx.packageManager.getPackageInfo("com.mojang.minecraftpe", 0).versionName }
                 catch (e: PackageManager.NameNotFoundException) { null }
        return SysSnapshot(mi.availMem shr 20, mi.totalMem shr 20, mi.lowMemory, thermal, t, mc)
    }
}

/** Measures frames of this app only. Runs only between start() and stop() (call from lifecycle). */
object PerfMonitor : Choreographer.FrameCallback {
    val stats = MutableStateFlow(PerfStats())
    private val frames = ArrayDeque<Double>()
    private var last = 0L; private var running = false; private var n = 0
    fun start() { if (running) return; running = true; last = 0; Choreographer.getInstance().postFrameCallback(this) }
    fun stop() { running = false; Choreographer.getInstance().removeFrameCallback(this) }
    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (last != 0L) {
            frames.addLast((frameTimeNanos - last) / 1e6)
            if (frames.size > 300) frames.removeFirst()
            if (++n % 30 == 0) stats.value = FrameStats.compute(frames)
        }
        last = frameTimeNanos
        Choreographer.getInstance().postFrameCallback(this)
    }
}
