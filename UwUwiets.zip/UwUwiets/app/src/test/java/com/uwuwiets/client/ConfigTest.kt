package com.uwuwiets.client

import com.uwuwiets.client.core.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
import java.io.File

class ConfigTest {
    @Test fun migratesV1OpacityIntoUi() {
        val v1 = Json.parseToJsonElement("""{"glassOpacity":0.3}""").jsonObject
        val out = ConfigMigrator.migrate(v1)
        assertEquals(ConfigMigrator.CURRENT, out["schemaVersion"]!!.jsonPrimitive.int)
        assertEquals(0.3, out["ui"]!!.jsonObject["opacity"]!!.jsonPrimitive.double, 1e-9)
        assertNull(out["glassOpacity"])
    }
    @Test fun roundTripAndCorruptRecovery() {
        val dir = createTempDir()
        val store = ConfigStore(dir)
        val c = AppConfig(profile = "Low", enabled = setOf("perf.fps"))
        store.save(c); assertEquals(c, store.load())
        File(dir, "config.json").writeText("{broken")
        assertEquals(AppConfig(), store.load())
        assertTrue(dir.listFiles()!!.any { it.name.startsWith("config.json.corrupt-") })
    }
    @Test fun v1FileLoadsViaStore() {
        val dir = createTempDir(); File(dir, "config.json").writeText("""{"glassOpacity":0.9}""")
        assertEquals(0.9f, ConfigStore(dir).load().ui.opacity, 1e-6f)
    }
}
