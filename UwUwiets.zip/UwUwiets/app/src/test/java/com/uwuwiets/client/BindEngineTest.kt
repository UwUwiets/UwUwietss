package com.uwuwiets.client

import com.uwuwiets.client.core.*
import org.junit.Assert.*
import org.junit.Test

class BindEngineTest {
    private val ev = mutableListOf<String>()
    private fun eng(vararg b: Binding) = BindEngine(b.toList()) { a, on -> ev += "$a:$on" }

    @Test fun comboFiresOnlyWhenComplete() {
        val e = eng(Binding("1", "x", setOf(1, 2, 3)))
        e.keyDown(1); e.keyDown(2); assertTrue(ev.isEmpty())
        e.keyDown(3); assertEquals(listOf("x:true"), ev)
    }
    @Test fun largerComboWinsOverSubset() {
        val e = eng(Binding("1", "a", setOf(1)), Binding("2", "b", setOf(1, 2)))
        e.keyDown(1); e.keyDown(2); assertEquals(listOf("a:true", "b:true"), ev)
    }
    @Test fun priorityBeatsSize() {
        val e = eng(Binding("1", "a", setOf(1), priority = 5), Binding("2", "b", setOf(1, 2)))
        e.keyDown(1); e.keyDown(2); assertEquals(listOf("a:true"), ev)
    }
    @Test fun holdReleasesOnKeyUpAndFocusLoss() {
        val e = eng(Binding("1", "h", setOf(1), BindMode.HOLD))
        e.keyDown(1); e.keyUp(1); assertEquals(listOf("h:true", "h:false"), ev)
        ev.clear(); e.keyDown(1); e.releaseAll(); assertEquals(listOf("h:true", "h:false"), ev)
    }
    @Test fun toggleFlips() {
        val e = eng(Binding("1", "t", setOf(1), BindMode.TOGGLE))
        e.keyDown(1); e.keyUp(1); e.keyDown(1)
        assertEquals(listOf("t:true", "t:false"), ev)
    }
    @Test fun detectsConflicts() {
        val l = listOf(Binding("1", "a", setOf(1, 2)), Binding("2", "b", setOf(2, 1)), Binding("3", "c", setOf(9)))
        assertEquals(setOf("1", "2"), BindEngine.conflicts(l))
    }
    @Test fun frameStats() {
        val s = FrameStats.compute(List(100) { 10.0 }.dropLast(1) + 50.0)
        assertEquals(50.0 + 0.0, 1000.0 / s.low1Fps, 1e-9)
        assertTrue(s.fps in 90.0..100.0)
    }
}
